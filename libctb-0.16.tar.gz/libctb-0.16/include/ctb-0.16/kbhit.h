#ifndef LIBCTB_KBHIT_H_INCLUDED_
#define LIBCTB_KBHIT_H_INCLUDED_

namespace ctb {

    char GetKey();

} // namespace ctb

#endif
